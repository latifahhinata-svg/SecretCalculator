
package com.example.secretcalculator;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

import android.media.MediaPlayer;

import java.util.Locale;

public class MainActivity extends Activity
        implements SensorEventListener {

    private TextView txtDisplay;

    private String currentInput = "0";
    private double firstValue = 0;
    private char operator = '\0';
    private boolean startNewNumber = true;

    private final int[] secretDigits = {0, 4, 0, 2, 1};

    private LocationManager locationManager;
    private LocationListener locationListener;

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private Sensor gyroscope;
    private TextView sensorText;
    private AlertDialog sensorDialog;

    private MediaPlayer mediaPlayer;

    private static final int REQ_LOCATION = 100;
    private static final int REQ_CAMERA = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtDisplay = findViewById(R.id.txtDisplay);

        locationManager =
                (LocationManager) getSystemService(LOCATION_SERVICE);

        sensorManager =
                (SensorManager) getSystemService(SENSOR_SERVICE);

        accelerometer = sensorManager.getDefaultSensor(
                Sensor.TYPE_ACCELEROMETER);

        gyroscope = sensorManager.getDefaultSensor(
                Sensor.TYPE_GYROSCOPE);

        setupNumber(R.id.btn0, "0");
        setupNumber(R.id.btn1, "1");
        setupNumber(R.id.btn2, "2");
        setupNumber(R.id.btn3, "3");
        setupNumber(R.id.btn4, "4");
        setupNumber(R.id.btn5, "5");
        setupNumber(R.id.btn6, "6");
        setupNumber(R.id.btn7, "7");
        setupNumber(R.id.btn8, "8");
        setupNumber(R.id.btn9, "9");

        setupOperator(R.id.btnPlus, '+');
        setupOperator(R.id.btnMinus, '-');
        setupOperator(R.id.btnMultiply, '*');
        setupOperator(R.id.btnDivide, '/');

        findViewById(R.id.btnDot).setOnClickListener(v -> {
            if (startNewNumber) {
                currentInput = "0";
                startNewNumber = false;
            }

            if (!currentInput.contains(".")) {
                currentInput += ".";
            }

            updateDisplay();
        });

        findViewById(R.id.btnClear).setOnClickListener(v -> {
            currentInput = "0";
            firstValue = 0;
            operator = '\0';
            startNewNumber = true;
            updateDisplay();
        });

        findViewById(R.id.btnDelete).setOnClickListener(v -> {
            if (!startNewNumber && currentInput.length() > 1) {
                currentInput = currentInput.substring(
                        0, currentInput.length() - 1);
            } else {
                currentInput = "0";
            }

            updateDisplay();
        });

        findViewById(R.id.btnEquals).setOnClickListener(v -> calculate());
    }

    private void setupNumber(int id, String number) {
        findViewById(id).setOnClickListener(v -> {
            if (startNewNumber) {
                currentInput = number;
                startNewNumber = false;
            } else if (currentInput.equals("0")) {
                currentInput = number;
            } else if (currentInput.length() < 15) {
                currentInput += number;
            }

            updateDisplay();
        });
    }

    private void setupOperator(int id, char selectedOperator) {
        findViewById(id).setOnClickListener(v -> {
            try {
                firstValue = Double.parseDouble(currentInput);
                operator = selectedOperator;
                startNewNumber = true;
            } catch (NumberFormatException e) {
                showMessage("Angka tidak valid");
            }
        });
    }

    private void calculate() {
        if (operator == '\0') return;

        double secondValue;

        try {
            secondValue = Double.parseDouble(currentInput);
        } catch (NumberFormatException e) {
            showMessage("Angka tidak valid");
            return;
        }

        double result;

        switch (operator) {
            case '+':
                result = firstValue + secondValue;
                break;

            case '-':
                result = firstValue - secondValue;
                break;

            case '*':
                result = firstValue * secondValue;
                break;

            case '/':
                if (secondValue == 0) {
                    showMessage("Tidak bisa dibagi nol");
                    return;
                }
                result = firstValue / secondValue;
                break;

            default:
                return;
        }

        if (Double.isNaN(result) || Double.isInfinite(result)) {
            showMessage("Hasil tidak valid");
            return;
        }

        currentInput = formatNumber(result);
        updateDisplay();

        // Fitur rahasia aktif jika hasil sama dengan digit NIM.
        if (result >= 0 && result <= 9
                && Math.abs(result - Math.rint(result)) < 0.000001) {
            activateSecret((int) Math.rint(result));
        }

        operator = '\0';
        startNewNumber = true;
    }

    private String formatNumber(double number) {
        if (number == Math.rint(number)) {
            return String.format(Locale.US, "%.0f", number);
        }

        return String.format(Locale.US, "%.6f", number)
                .replaceAll("0+$", "")
                .replaceAll("\\.$", "");
    }

    private void updateDisplay() {
        txtDisplay.setText(currentInput);
    }


    private void activateSecret(int result) {
        java.util.ArrayList<String> features =
                new java.util.ArrayList<>();

        java.util.ArrayList<Integer> actions =
                new java.util.ArrayList<>();

        for (int i = 0; i < secretDigits.length; i++) {
            if (secretDigits[i] == result) {
                switch (i) {
                    case 0:
                        features.add("Kamera");
                        actions.add(0);
                        break;

                    case 1:
                        features.add("Putar Audio");
                        actions.add(1);
                        break;

                    case 2:
                        features.add("Buka Gambar");
                        actions.add(2);
                        break;

                    case 3:
                        features.add("Tampilkan GPS");
                        actions.add(3);
                        break;

                    case 4:
                        features.add("Gyroscope & Accelerometer");
                        actions.add(4);
                        break;
                }
            }
        }

        if (features.isEmpty()) {
            return;
        }

        if (features.size() == 1) {
            runSecretFeature(actions.get(0));
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("Pilih Fitur Rahasia")
                .setItems(
                        features.toArray(new String[0]),
                        (dialog, which) ->
                                runSecretFeature(actions.get(which))
                )
                .setNegativeButton("Batal", null)
                .show();
    }

    private void runSecretFeature(int action) {
        switch (action) {
            case 0:
                openCamera();
                break;

            case 1:
                playAudio();
                break;

            case 2:
                openImage();
                break;

            case 3:
                openGPS();
                break;

            case 4:
                openSensors();
                break;
        }
    }


    // FITUR 1: KAMERA
    private void openCamera() {
        Intent intent = new Intent(
                android.provider.MediaStore.ACTION_IMAGE_CAPTURE);

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, REQ_CAMERA);
        } else {
            showMessage("Aplikasi kamera tidak tersedia");
        }
    }

    // FITUR 2: AUDIO
    private void playAudio() {
        try {
            if (mediaPlayer != null) {
                mediaPlayer.release();
                mediaPlayer = null;
            }

            mediaPlayer = MediaPlayer.create(
                    this, R.raw.secret_audio);

            if (mediaPlayer != null) {
                mediaPlayer.setOnCompletionListener(mp -> {
                    mp.release();
                    mediaPlayer = null;
                });

                mediaPlayer.start();
            } else {
                showMessage("File audio tidak dapat dibuka");
            }
        } catch (Exception e) {
            showMessage("Gagal memutar audio");
        }
    }

    // FITUR 3: GAMBAR
    private void openImage() {
        ImageView image = new ImageView(this);
        image.setImageResource(R.drawable.secret_image);
        image.setAdjustViewBounds(true);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setPadding(12, 12, 12, 12);

        new AlertDialog.Builder(this)
                .setTitle("Secret Image")
                .setView(image)
                .setPositiveButton("Tutup", (d, w) -> d.dismiss())
                .show();
    }

    // FITUR 4: GPS
    private void openGPS() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(
                Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            requestPermissions(
                    new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                    }, REQ_LOCATION);

            return;
        }

        try {
            Location lastLocation = null;

            if (locationManager.isProviderEnabled(
                    LocationManager.GPS_PROVIDER)) {
                lastLocation = locationManager.getLastKnownLocation(
                        LocationManager.GPS_PROVIDER);
            }

            if (lastLocation != null) {
                showLocation(lastLocation);
            } else {
                showMessage("Mencari lokasi GPS...");

                locationListener = location -> {
                    showLocation(location);
                    locationManager.removeUpdates(locationListener);
                    locationListener = null;
                };

                locationManager.requestLocationUpdates(
                        LocationManager.GPS_PROVIDER,
                        1000,
                        1,
                        locationListener
                );
            }

        } catch (SecurityException e) {
            showMessage("Izin lokasi belum tersedia");
        } catch (Exception e) {
            showMessage("GPS tidak tersedia. Aktifkan lokasi.");
        }
    }

    private void showLocation(Location location) {
        String info = String.format(
                Locale.US,
                "Latitude: %.6f\nLongitude: %.6f\nAkurasi: %.1f meter",
                location.getLatitude(),
                location.getLongitude(),
                location.getAccuracy());

        new AlertDialog.Builder(this)
                .setTitle("Lokasi GPS")
                .setMessage(info)
                .setPositiveButton("OK", null)
                .show();
    }

    // FITUR 5: ACCELEROMETER DAN GYROSCOPE
    private void openSensors() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 20, 32, 20);

        sensorText = new TextView(this);
        sensorText.setTextColor(Color.BLACK);
        sensorText.setTextSize(16);
        sensorText.setText("Membaca sensor...");

        layout.addView(sensorText);

        sensorDialog = new AlertDialog.Builder(this)
                .setTitle("Sensor Gerak")
                .setView(layout)
                .setPositiveButton("Tutup", (d, w) -> {
                    stopSensors();
                })
                .create();

        sensorDialog.setOnDismissListener(d -> stopSensors());
        sensorDialog.show();

        if (accelerometer != null) {
            sensorManager.registerListener(
                    this, accelerometer,
                    SensorManager.SENSOR_DELAY_UI);
        }

        if (gyroscope != null) {
            sensorManager.registerListener(
                    this, gyroscope,
                    SensorManager.SENSOR_DELAY_UI);
        }

        if (accelerometer == null && gyroscope == null) {
            sensorText.setText("Sensor tidak tersedia di perangkat ini.");
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (sensorText == null) return;

        String label = event.sensor.getType()
                == Sensor.TYPE_ACCELEROMETER
                ? "Accelerometer" : "Gyroscope";

        String unit = event.sensor.getType()
                == Sensor.TYPE_ACCELEROMETER
                ? "m/s²" : "rad/s";

        String data = String.format(
                Locale.US,
                "%s\nX: %.3f\nY: %.3f\nZ: %.3f\nSatuan: %s\n\n",
                label,
                event.values[0],
                event.values[1],
                event.values[2],
                unit);

        String previous = sensorText.getText().toString();

        if (label.equals("Accelerometer")) {
            sensorText.setText(data + extractGyroscope(previous));
        } else {
            sensorText.setText(extractAccelerometer(previous) + data);
        }
    }

    private String extractAccelerometer(String text) {
        int end = text.indexOf("Gyroscope");
        return end >= 0 ? text.substring(end) : "";
    }

    private String extractGyroscope(String text) {
        int start = text.indexOf("Gyroscope");
        return start >= 0 ? text.substring(start) : "";
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Tidak memerlukan tindakan khusus.
    }

    private void stopSensors() {
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
        sensorText = null;
    }

    private void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode, permissions, grantResults);

        if (requestCode == REQ_LOCATION) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openGPS();
            } else {
                showMessage("Izin lokasi diperlukan untuk fitur GPS");
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        stopSensors();

        if (locationManager != null && locationListener != null) {
            locationManager.removeUpdates(locationListener);
            locationListener = null;
        }

        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}
